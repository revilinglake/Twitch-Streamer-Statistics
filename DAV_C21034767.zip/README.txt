INSTRUCTIONS TO RUN ALL FILES:

1) Data Analysis is in python notebook format in a file titled "DA_C21034767".
   The required packages to run this code is in the "reuirements.txt" file. A cell has been dedicated to install packages within the notebook aswell.
   This file contains all the code to process the dataset. 
   It is not required to run the code since the dataset used in Tableau is already processed.

2) Data Visualization is done in Tableau and is in the workbook titled "DV_C21034767".
   Once opened, kindly run the presentation while on the 1st dashboard titled "Cover Sheet".
   The dashboards can then be navigated to interact with the visualizations.
   There is no need to upload any dataset or any other prerequirements to run the workbook.

To avoid cofusion of dataset:
	"twitch_streamers_data": Raw dataset
	"twitchstreamers_data": Processed Dataset for Visualization